CEP HEROES STUDIO - PROYEK ANDROID OFFLINE

Isi:
- app/src/main/assets/index.html: HTML asli yang kamu kirim, tidak didesain ulang.
- MainActivity.kt: pembungkus Android WebView.
- Ikon aplikasi CH sederhana.

Cara menghasilkan APK:
1. Buka proyek ini di Android Studio pada komputer.
2. Tunggu Gradle Sync selesai. Pastikan Android SDK 35 terpasang.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug akan muncul di app/build/outputs/apk/debug/app-debug.apk.
5. Pindahkan APK ke HP Android, buka, lalu izinkan instalasi dari sumber tersebut jika diminta.

Catatan:
- Aplikasi memuat HTML secara lokal; hosting tidak diperlukan.
- Internet hanya dibutuhkan oleh elemen eksternal yang masih dipanggil HTML (jika ada).
- Data disimpan melalui localStorage WebView pada perangkat.
- Ekspor/impor backup tersedia di menu Pengaturan.
- File ini adalah proyek sumber Android Studio, bukan APK hasil kompilasi.
